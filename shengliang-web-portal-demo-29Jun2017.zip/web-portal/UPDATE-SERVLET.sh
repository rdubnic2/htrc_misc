#!/bin/bash


/bin/cp etc/jetty.xml etc/realm.properties ../solr-server-head/etc/.

/bin/cp WEB-INF/*.xml ../solr-server-head/solr-webapp/webapp/WEB-INF/.


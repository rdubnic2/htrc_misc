#!/bin/bash

/bin/cp *.html *.js *.css ../solr-server-head/solr-webapp/webapp/.


